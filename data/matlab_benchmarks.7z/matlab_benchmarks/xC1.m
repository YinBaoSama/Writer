function x = xC1(i)
	if i==0
        x=1;
    elseif(i==1)
        x= 1;
    elseif(i==2)
        x= 0;
    elseif(i==3)
        x= -1;
	else x=i-4;
    end