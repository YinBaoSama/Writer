function y = yC4(i)
	if(i==0)y= 0;
	elseif(i==1)y= -1;
	elseif(i==2)y= -2;
	elseif(i==3)y= -3;
	elseif(i==4)y= -4;
	elseif(i==5)y= -4;
	elseif(i==6)y= -4;
	elseif(i==7)y= -4;
	elseif(i==8)y= -4;
	elseif(i==9)y= -4;
	elseif(i==10)y= -4;
	elseif(i==11)y= -4;
	elseif(i==12)y= -4;
	elseif(i==13)y= -3;
	elseif(i==14)y= -2;
	elseif(i==15)y= -1;
	else y= yC4(i-16);
    end