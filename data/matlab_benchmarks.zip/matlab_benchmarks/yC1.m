function y = yC1(i)
	if i==0
        y=0;
    elseif(i==1)
        y= -1;
    elseif(i==2)
        y= -1;
    elseif(i==3)
        y= -1;
    else
        y=i-4;
    end